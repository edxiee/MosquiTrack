import type { RouteObject } from "react-router-dom";

export const lguRoutes: RouteObject[] = [];