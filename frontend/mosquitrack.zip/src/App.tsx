export default function App() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100">
      <h1 className="text-5xl font-bold text-slate-900">
        MosquiTrack
      </h1>
    </main>
  );
}