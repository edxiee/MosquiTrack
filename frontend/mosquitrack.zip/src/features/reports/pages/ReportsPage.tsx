export default function ReportsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Reports</h1>
      <p className="mt-2 text-slate-600">
        Statistical reporting module coming soon.
      </p>
    </div>
  );
}